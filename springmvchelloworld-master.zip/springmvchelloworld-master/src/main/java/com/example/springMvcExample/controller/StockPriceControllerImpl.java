package com.example.springMvcExample.controller;

import java.math.BigDecimal;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.print.attribute.standard.DateTimeAtCompleted;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.springMvcExample.model.Company;
import com.example.springMvcExample.model.Sector;
import com.example.springMvcExample.model.StockPrice;
import com.example.springMvcExample.service.CompanyService;
import com.example.springMvcExample.service.StockPriceService;

@Controller
public class StockPriceControllerImpl {

	@Autowired
	private StockPriceService stockPriceService;
	
	
	@Autowired
	private CompanyService companyService;
	
	@RequestMapping(path="/stockPriceList")
	public ModelAndView getStockPriceList() throws Exception {
		ModelAndView mv=new ModelAndView();
		mv.setViewName("stockPriceList");
		mv.addObject("stockPriceList",stockPriceService.getStockList());
		return mv;
	}
	
/*	@RequestMapping(path="/insertStockPrice",method = RequestMethod.GET)
	public String insert()
	{
		StockPrice stock=new StockPrice();
		stock.setCurrentPrice(3000);
		stock.setDate(new Date());
		stock.setStockCode(3);
		stock.setTime(new Date());
		
		Company company=new Company();
		company.setCompanyCode(103);
		company.setBoardOfDirectors("xyz");
		company.setCeoName("dfd");
		company.setCompanyName("cts");
		company.setTurnover(new BigDecimal(434.45d));
		company.setWriteup("hii");
		stock.setCompany(company);
	
		try {
			//companyService.insertCompany(company);
			stockPriceService.insertStock(stock);
			
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "redirect:companyList";
	}*/
	
	@RequestMapping(path = "/registerStockPricePage", method = RequestMethod.GET)
	public ModelAndView registerStockPricePage(Model model) throws Exception {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("registerStockPrice");
		model.addAttribute("stockPriceRegister", new StockPrice());
		return mv;
	}
	
	@RequestMapping(value = "/registerStockPrice", method = RequestMethod.POST)
	public ModelAndView registerStockPrice( @ModelAttribute("stockPriceRegister") StockPrice stockPrice, BindingResult result,
			HttpServletRequest request, HttpSession session, ModelMap map) throws SQLException {
		ModelAndView mav = null;
		if (result.hasErrors()) {

			map.addAttribute("stockPriceRegister", stockPrice);
			mav = new ModelAndView("registerStockPrice");
			return mav;
		}

		else {
			map.addAttribute("stockPriceRegister", stockPrice);
			stockPriceService.insertStock(stockPrice);
			mav = new ModelAndView("stockPriceList");
			mav.addObject("stockPriceList", stockPriceService.getStockList());
			return mav;
		}

	}

	
	
}
