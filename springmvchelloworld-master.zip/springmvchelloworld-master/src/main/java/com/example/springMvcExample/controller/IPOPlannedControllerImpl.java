package com.example.springMvcExample.controller;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.example.springMvcExample.model.Company;
import com.example.springMvcExample.model.IPOPlanned;
import com.example.springMvcExample.model.Sector;
import com.example.springMvcExample.service.CompanyService;
import com.example.springMvcExample.service.IPOPlannedService;
import com.example.springMvcExample.service.StockExchangeService;

@Controller
public class IPOPlannedControllerImpl implements IPOPlannedController {

	@Autowired
	private IPOPlannedService ipoPlannedService;

	@Autowired
	private CompanyService companyService;

	@Autowired
	private StockExchangeService stockExchangeService;

	@Override
	public boolean insertIPO(IPOPlanned ipoPlanned) throws SQLException {
		// TODO Auto-generated method stub
		return ipoPlannedService.insertIPO(ipoPlanned);
	}

	@RequestMapping(path = "/registerIPOPage", method = RequestMethod.GET)
	public ModelAndView registerIPOPage(Model model) throws Exception {
		ModelAndView mv = new ModelAndView();
		List companyList = (List) companyService.getCompanyList();
		List stockExchangeList = (List) stockExchangeService.getStockExchangeList();
		mv.setViewName("registerIPO");
		model.addAttribute("ipoPlanned", new IPOPlanned());
		model.addAttribute("companyList", companyList);
		model.addAttribute("stockExchangeList", stockExchangeList);
		return mv;
	}

	@RequestMapping(value = "/registerIPO", method = RequestMethod.GET)
	public ModelAndView registerSector(@Valid @ModelAttribute("ipoPlanned") IPOPlanned ipoPlanned, BindingResult result,
			HttpServletRequest request, HttpSession session, ModelMap map) throws SQLException {
		ModelAndView mav = null;
		if (result.hasErrors()) {

			map.addAttribute("ipoPlanned", ipoPlanned);
			mav = new ModelAndView("registerIPO");
			return mav;
		}

		else {
			map.addAttribute("ipoPlanned", ipoPlanned);
			ipoPlannedService.insertIPO(ipoPlanned);
			mav = new ModelAndView("ipoPlannedList");
			mav.addObject("ipoPlannedList", ipoPlannedService.getIPOPlannedList());
			return mav;
		}

	}

	@RequestMapping(path = "/ipoPlannedList")
	public ModelAndView getIPOPlannedList() throws Exception {
		ModelAndView mv = new ModelAndView();
		mv.setViewName("ipoPlannedList");
		mv.addObject("ipoPlannedList", ipoPlannedService.getIPOPlannedList());
		return mv;
	}

}
