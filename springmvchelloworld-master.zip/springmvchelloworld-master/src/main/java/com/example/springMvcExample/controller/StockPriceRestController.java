package com.example.springMvcExample.controller;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.springMvcExample.dao.CompanyDao;
import com.example.springMvcExample.dao.StockPriceDao;
import com.example.springMvcExample.model.Company;
import com.example.springMvcExample.model.StockPrice;

@RestController
public class StockPriceRestController {

	@Autowired
	StockPriceDao stockPriceDao;

	@Autowired
	CompanyDao companyDao;

	@GetMapping("/stockPriceList/{companyCode}")
	public List<StockPrice> StockPriceList(@PathVariable("companyCode") int companyCode) {

		return stockPriceDao.findBycompanyCode(companyCode);
	}

	@GetMapping("/stockPriceDisplay/{companyCode}/{startDate}/{endDate}")
	public List<StockPrice> StockPriceDisplay(@PathVariable("companyCode") int companyCode,
			@PathVariable("startDate") Date startDate, @PathVariable("endDate") Date endDate) {

		return stockPriceDao.findBydate(companyCode, startDate, endDate);
	}

	@GetMapping("/stockPrice/{sectorId}/{startDate}/{endDate}")
	public Double CompanyDetails(@PathVariable("sectorId") Integer sectorId, @PathVariable("startDate") Date startDate,
			@PathVariable("endDate") Date endDate) {

		Double sum = 0.0;

		List<Company> companyDetails = companyDao.findBysectorId(sectorId);
		List<Double> stockPrice = new ArrayList<Double>();
		for (int i = 0; i < companyDetails.size(); i++) {
			Company company = (Company) companyDetails.get(i);
			Integer companyCode = company.getCompanyCode();
			stockPriceDao.findBycompanyCode(companyCode, startDate, endDate).forEach(stockPrice::add);

		}
		for (Double price : stockPrice) {
			sum = sum + price;
		}

		return sum;
	}

}
