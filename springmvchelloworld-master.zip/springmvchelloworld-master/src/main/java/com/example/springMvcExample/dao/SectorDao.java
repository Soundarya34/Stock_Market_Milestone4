package com.example.springMvcExample.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.springMvcExample.model.Sector;

public interface SectorDao extends JpaRepository<Sector, Integer> {

}
