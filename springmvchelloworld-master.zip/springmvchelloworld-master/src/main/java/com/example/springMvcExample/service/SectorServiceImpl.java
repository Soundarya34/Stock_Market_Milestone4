package com.example.springMvcExample.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.springMvcExample.dao.SectorDao;
import com.example.springMvcExample.model.Sector;

@Service
public class SectorServiceImpl implements SectorService {

	@Autowired
	private SectorDao sectorDao;

	@Override
	public boolean insertSector(Sector sector) throws SQLException {
		// TODO Auto-generated method stub
		sectorDao.save(sector);
		return true;
	}

	@Override
	public List<Sector> getSectorList() throws SQLException {
		// TODO Auto-generated method stub
		return sectorDao.findAll();
	}

}
